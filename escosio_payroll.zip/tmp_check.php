<?php
$db = new PDO('sqlite:database/database.sqlite');
foreach ($db->query('SELECT id, email, role, password FROM users ORDER BY id') as $row) {
    echo $row['email'] . ' => ' . $row['role'] . ' => ' . substr($row['password'], 0, 30) . PHP_EOL;
}
