<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\company project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>